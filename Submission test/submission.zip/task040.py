#TODO  # TO BE DONE BY Suhrid Sadman Abrar
def p(j):
	A=range;c=[J[:]for J in j];E=j[0][0]==j[0][9];k,W=(j[0][0],j[9][0])if E else(j[0][0],j[0][9]);l=next(J for a in j for J in a if J and J not in[k,W])
	for J in A(10):
		for a in A(10):
			if j[J][a]==l:C=(J,9-J)if E else(a,9-a);c[J][a]=k if C[0]<C[1]else W
	return c