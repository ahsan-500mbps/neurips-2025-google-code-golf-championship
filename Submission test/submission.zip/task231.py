# TODO  # TO BE DONE BY Suhrid Sadman Abrar
p=lambda g:[[g[i%5][j%6]for j in range(len(g[0])*2)]for i in range(len(g)*1)]