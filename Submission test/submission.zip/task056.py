p=lambda g:[[{171:1,341:2,118:3,186:6}[sum((g[i][j]>0)<<(i*3+j)for i in range(3)for j in range(3))]]]
