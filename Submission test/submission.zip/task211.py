# TODO  # TO BE DONE BY Suhrid Sadman Abrar
def p(j):j=[R[::-1]+R for R in j];A=[j[2],j[1],j[0]];return A+j+A