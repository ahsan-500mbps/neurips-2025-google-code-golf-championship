# TODO  # TO BE DONE BY Nafis Fuad
p=lambda j:[*map(list,zip(*j))][::-1]