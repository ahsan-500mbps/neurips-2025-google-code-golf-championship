# TODO  # TO BE DONE BY Suhrid Sadman Abrar
def p(j):
	A={};c=[[[j[0][0],j[0][1]],[j[1][0],j[1][1]]],[[j[3][0],j[3][1]],[j[4][0],j[4][1]]],[[j[0][3],j[0][4]],[j[1][3],j[1][4]]],[[j[3][3],j[3][4]],[j[4][3],j[4][4]]]]
	for E in c:
		E=str(E)
		if E in A:A[E]+=1
		else:A[E]=1
	for E in A:
		if A[E]==1:return eval(E)