# TODO  # TO BE DONE BY Nafis Fuad
def p(j,A=0):
 c={1:[[1,0,0],[0,0,0],[0,0,0]],2:[[1,0,1],[0,0,0],[0,0,0]],3:[[1,0,1],[0,1,0],[0,0,0]],4:[[1,0,1],[0,1,0],[1,0,0]],5:[[1,0,1],[0,1,0],[1,0,1]]}
 for E in range(0,len(j[0])-2+1,1):
  for k in range(0,len(j)-2+1,1):
   W=j[E:E+2];W=[R[k:k+2]for R in W];l=[i for s in W for i in s]
   if min(l)>0:A+=1
 return c[A]