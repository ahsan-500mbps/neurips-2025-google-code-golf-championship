def p(g):
 r=lambda x:[*map(list,zip(*x[::-1]))];a=r(g);b=r(a);return[*map(list.__add__,g,a),*map(list.__add__,r(b),b)]