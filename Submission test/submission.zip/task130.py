def p(j):
 A=range
 c=[[0]*3for _ in A(3)]
 for E in A(3):
  for k in A(3):
   W={}
   for l in A(3):
    for J in A(3):a=j[E*3+l][k*3+J];W[a]=W.get(a,0)+1
   c[E][k]=max(W,key=W.get)
 return c