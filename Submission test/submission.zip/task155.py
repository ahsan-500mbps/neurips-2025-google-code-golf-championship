p=lambda g:g[::-1]
