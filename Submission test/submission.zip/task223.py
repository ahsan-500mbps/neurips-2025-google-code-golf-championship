def p(g):
 X=[]
 for r in g:
  for i in range(3):
   X+=[sum([[c]*3 for c in r],[])]
 return X