def p(j):
	A=range;D,E=len(j),len(j[0]);B=[B for B in A(D)if all(j[B][A]==0 for A in A(E))];C=[B for B in A(E)if all(j[A][B]==0 for A in A(D))];B=[-1]+B+[D];C=[-1]+C+[E];G=[]
	for H in A(len(B)-1):
		F=[]
		for I in A(len(C)-1):
			for J in A(B[H]+1,B[H+1]):
				for K in A(C[I]+1,C[I+1]):
					if j[J][K]:F.append(j[J][K]);break
				else:continue
				break
		if F:G.append(F)
	return G