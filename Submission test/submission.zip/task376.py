# TODO  # TO BE DONE BY Nafis Fuad
p=lambda j:(j+j[-2:0:-1])*2+j[:1]