def p(g):
 for i in g:
  if i[0]==i[-1]:i[:]=i[:1]*len(i)
 return g