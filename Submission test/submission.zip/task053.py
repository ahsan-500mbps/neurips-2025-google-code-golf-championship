def p(g):
  w=len(g[0]);z=[0]*w
  return [z]+g[:-1]
