p=lambda g:g[-1:]+g[:-1]
