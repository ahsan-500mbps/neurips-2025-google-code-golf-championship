def p(m):
 I=range(k:=len(m));h=m[2][2];r=eval(str(n:=[[v*(v!=h)for v in R]for R in m]));E=lambda t:(t.index(c),k-t[::-1].index(c))
 for c in I:
  for i in I:
   if c in(t:=n[i]):a,b=E(t);r[i][a:b]=[c]*(b-a)
   if c in(t:=[r[i]for r in n]):
    for j in range(*E(t)):r[j][i]=c
 return[[(h,r[i][j])[m[i][j]!=h]for j in I]for i in I]