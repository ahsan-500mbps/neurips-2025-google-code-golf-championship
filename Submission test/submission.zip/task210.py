# TODO  # TO BE DONE BY Suhrid Sadman Abrar
p=lambda j:j+j[::-1]