def p(g):
 for i,a in enumerate(g[-1]):
  if a:
   for r in g:r[i:10:2]=[a]*len(r[i:10:2])
   s=g[0];s[i+1:10:4]=[5]*len(s[i+1:10:4])
   s=g[-1];s[i+3:10:4]=[5]*len(s[i+3:10:4]);break
 return g