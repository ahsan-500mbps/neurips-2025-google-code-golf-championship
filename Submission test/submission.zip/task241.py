# TODO  # TO BE DONE BY Suhrid Sadman Abrar
p=lambda j:[*map(list,zip(*j))]