# TODO  # TO BE DONE BY Suhrid Sadman Abrar
p=lambda j:[E*2 for E in j]